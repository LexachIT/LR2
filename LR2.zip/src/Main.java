import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Введите X: ");
        double x = in.nextInt();
        System.out.println("Введите N: ");
        int n = in.nextInt();
        double sum = 0;
        for (int i = 0; i < n; i++) {
            sum += ((Math.pow(-1, i) * Math.pow(x, 2*i)) / factorial(2*i+1));
        }
        System.out.println("Summ: " + sum);
    }
    public static double factorial(double num)
    {
        double fact = 1;

        for (double i = 1; i <= num; i++)
        {
            fact *= i;
        }
        return fact;
    }
    }


